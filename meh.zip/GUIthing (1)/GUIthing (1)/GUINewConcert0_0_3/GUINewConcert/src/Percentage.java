public class Percentage 
{
    
}
