package guinewconcert;

import java.awt.Graphics;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.GridLayout;

public class Seats extends JPanel implements ActionListener {
    
    JLabel lblNumbers;
    JLabel lblRowA;
    JLabel lblRowB;
    JLabel lblRowC;
    JLabel lblRowD;
    JLabel lblRowE;
    JLabel lblRowF;
    JLabel lblRowG;
    JLabel lblRowH;
    JLabel lblRowI;
    
    public JButton[][] buttons; // declaring array for buttons
    public final int btn_count = 90; // declaring a counter for the array
    public JPanel BronzeSeats;
    public JPanel GoldSeats;
    public JPanel SilverSeats;
    
    private GridLayout experimentLayout;
    
        public void paintComponent(Graphics g){
         g.drawLine(30,50,90,50); // Draw a horizontal line line from (30,90) to (50,50)
         g.drawLine(150,50,240,50); 
         g.drawLine(240,50,240,120);
         g.drawLine(240,120,480,120);
         g.drawLine(480,120,480,50);
         g.drawLine(480,50,560,50);
         g.drawLine(620,50,680,50);
            }
        
    public Seats(){
       
                
        lblNumbers = new JLabel();
        lblNumbers.setText("  10        9        8        7        6               5        4         3        2        1");
        lblNumbers.setBounds(50,100,550,50);
        add(lblNumbers);
        
        lblRowA = new JLabel();
        lblRowA.setText("A");
        add(lblRowA);
                
        lblRowB = new JLabel();
        lblRowB.setText("B");
        add(lblRowB);
        
        lblRowC = new JLabel();
        lblRowC.setText("C");
        add(lblRowC);
        
        lblRowD = new JLabel();
        lblRowD.setText("D");
        add(lblRowD);
        
        lblRowE = new JLabel();
        lblRowE.setText("E");
        add(lblRowE);
        
        lblRowF = new JLabel();
        lblRowF.setText("F");
        add(lblRowF);
        
        lblRowG = new JLabel();
        lblRowG.setText("G");
        add(lblRowG);
        
        lblRowH = new JLabel();
        lblRowH.setText("H");
        add(lblRowH);
                
        lblRowI = new JLabel();
        lblRowI.setText("I");
        add(lblRowI);
        
        
        GoldSeats = new JPanel();
        SilverSeats = new JPanel();
        BronzeSeats = new JPanel();
             
        buttons = new JButton[btn_count/30][btn_count/3]; //initialising the array
            
        for(int i = 0; i < 3; i++){ //setting a for loop for the 3 colours
            for(int j=0; j< 30; j++){ // for loop for 30 buttons
                buttons[i][j] = new JButton();

                        if(i == 0){
                buttons[i][j].setBackground(new java.awt.Color(204, 153, 0));
                buttons[i][j].setForeground(new java.awt.Color(204, 153, 0));
                experimentLayout =  new GridLayout(3,10);
                GoldSeats.setLayout(experimentLayout);
                GoldSeats.add(buttons[i][j]);
                add(GoldSeats); 
                
                        
                        }
                        else if (i == 1){

                buttons[i][j].setBackground(new java.awt.Color(153, 153, 153));
                buttons[i][j].setForeground(new java.awt.Color(153, 153, 153));
                SilverSeats.setLayout(experimentLayout);
                SilverSeats.add(buttons[i][j]);
               add(SilverSeats);  
                        }
                        else{
                buttons[i][j].setBackground(new java.awt.Color(153, 51, 0));
                buttons[i][j].setForeground(new java.awt.Color(153, 51, 0));
                BronzeSeats.setLayout(experimentLayout);
                BronzeSeats.add(buttons[i][j]);
                add(BronzeSeats);  
                        }
                buttons[i][j].setOpaque(true);
                buttons[i][j].addActionListener(new ActionListener() {
                    public void actionPerformed(java.awt.event.ActionEvent evt) {
                        btnseatActionPerformed(evt);
                    }
                });
            }
    }
        
        
}
    
 private void btnseatActionPerformed(java.awt.event.ActionEvent evt) {                                          
        
               
        String firstname = JOptionPane.showInputDialog("Please enter customer's first name");//A message box asking for the customers first name
        String secondname = JOptionPane.showInputDialog("Please enter customer's second name");//A message box asking for the customers second name
        
        JOptionPane.showConfirmDialog(null, "Customer's name is " + firstname + " " + secondname);//Validation ensuring information is what required
        
        
    }           

    @Override
    public void actionPerformed(ActionEvent e) {
        
    }
}           

   