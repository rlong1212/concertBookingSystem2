package guinewconcert;

import static guinewconcert.Events.summary;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import static javax.swing.JSplitPane.LEFT;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

public class Seats extends JPanel implements ActionListener 
{
    String msg = " ";//Declaring String for message
    //Declaration of the JLabels 
    JLabel lblNumbers;
    JLabel lblRowA;
    JLabel lblRowB;
    JLabel lblRowC;
    JLabel lblRowD;
    JLabel lblRowE;
    JLabel lblRowF;
    JLabel lblRowG;
    JLabel lblRowH;
    JLabel lblRowI;
    
    public JButton[][] buttons; // declaring array for buttons
    public JButton gold, silver, bronze;
    public final int btn_count = 90; // declaring a counter for the array
    //Declaring JPanel for the seating areas
    public JPanel BronzeSeats;
    public JPanel GoldSeats;
    public JPanel SilverSeats;
    //Declaring labels for booking
    private JLabel lblCreate, lblID, lblName, lblSeat, lblConcert, lblDate, lblTime ;
    private JTextField txtID, txtName, txtConcert, txtDate, txtTime, txtSeat;//Declaring text fields for booking
    JLabel lblReport;
    
    private JButton btnSave; //Declaring save booking button
    //Declaring search queries buttons
    JButton btnID;
    JButton btnSeatsBooked;
    //Declaring layout
    private GridLayout experimentLayout;
    public String id, name, seat, getSeat, concert, date, time, goldText;//Storing text box data into Strings
    public int number;
    public int l = 0;
    static String summary;
    
    HashMap<String,JButton> buttonCache = new HashMap<String,JButton>();
    
        public void paintComponent(Graphics g){
         g.drawLine(30,50,90,50); // Drawing lines for stage. Draw a horizontal line from (30,90) to (50,50)
         g.drawLine(150,50,240,50); 
         g.drawLine(240,50,240,120);
         g.drawLine(240,120,480,120);
         g.drawLine(480,120,480,50);
         g.drawLine(480,50,560,50);
         g.drawLine(620,50,680,50);
            }
        
    public Seats(){
        setLayout(null);
        
        String path = "P:\\GUINewConcert0_0_6\\GUINewConcert0_0_3\\GUINewConcert\\src\\addeventNewEvernt.txt"; //path to the file
        String Name = "Name:"; //looking for the name
        try
        {
            BufferedReader reader = new BufferedReader(new FileReader(path)); //creating a reader to read to file.txt
            String line = null; //variable to go through lines
            //while loop
            while((line = reader.readLine()) != null) //while the reader is still reading lines (stops when is null aka no more lines)
            {
                if(line.contains(Name)) //.contains used to find all lines that contain the String from Name variable
                {
                    txtConcert = new JTextField(line);
                }
            }
            reader.close(); //closing the reader
        }
        catch (Exception exc)
        {
            System.out.println("Error, could not get concert name");//Printing message to user
        }
        //Instantiation of JLabels, JTextField and JButtons
        lblID = new JLabel();
        lblName = new JLabel();
        lblSeat = new JLabel();
        lblConcert = new JLabel();
        lblDate = new JLabel();
        lblTime = new JLabel();
        txtID = new JTextField();
        txtName = new JTextField();
        txtSeat = new JTextField();
        txtDate = new JTextField();
        txtTime = new JTextField(); 
        btnSave = new JButton();
        lblReport = new JLabel();
        btnID = new JButton();
        btnSeatsBooked = new JButton();
        
        //Setting placement of JButtons, JLabels and JTextFields
        btnSave.setBounds(820, 350, 100, 50);
        btnID.setBounds (90, 530,150,30);
        btnSeatsBooked.setBounds(350,530,150,30);
        
        lblID.setBounds(750, 50, 150, 50);
        lblName.setBounds(750, 100, 150, 50);
        lblSeat.setBounds(750, 150, 150, 50);
        lblDate.setBounds(750, 200, 150, 50);
        lblTime.setBounds(750, 250, 150, 50);
        lblConcert.setBounds(750, 300, 150, 50);
        
        txtID.setBounds(800, 60, 150, 25);
        txtName.setBounds(800, 110, 150, 25);
        txtSeat.setBounds(800, 160, 150, 25);
        txtDate.setBounds(800, 210, 150, 25);
        txtTime.setBounds(800, 260, 150, 25);
        txtConcert.setBounds(800, 310, 150, 25);
        
        btnSave.setText("Save");
        btnSave.addActionListener(this);
        
        btnID.setText("Query Bookings");
        btnID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IDactionPerformed(evt);
            }

            
        });
        
        btnSeatsBooked.setText("No. of avalible seats");
        btnSeatsBooked.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                seatActionPerformed(evt);
            }
        });
        
        lblID.setText("ID: ");
        lblName.setText("Name: ");
        lblSeat.setText("Seat: ");
        lblDate.setText("Date: ");
        lblTime.setText("Time: ");
        lblConcert.setText("Concert: ");
        
        add(btnSave);
        add(btnID);
        add(btnSeatsBooked);
        add(lblID);
        add(lblName);
        add(lblSeat);
        add(lblDate);
        add(lblTime);
        add(lblConcert);
        
        add(txtID);
        add(txtName);
        add(txtSeat);
        add(txtConcert);
        add(txtDate);
        add(txtTime);
        
        lblCreate = new JLabel();
        lblCreate.setText("Create New Booking");
        lblCreate.setBounds(500, 0, 150, 50);
        add(lblCreate);
        
        lblNumbers = new JLabel();
        lblNumbers.setText("  1               2               3               4               5               6               7               8                9               10");
        lblNumbers.setBounds(90,130,590,50);
        add(lblNumbers);
        
        lblRowA = new JLabel();
        lblRowA.setText("A");
        lblRowA.setBounds(640,170,50,50);
        add(lblRowA);
                
        lblRowB = new JLabel();
        lblRowB.setText("B");
        lblRowB.setBounds(640,200,50,50);
        add(lblRowB);
        
        lblRowC = new JLabel();
        lblRowC.setText("C");
        lblRowC.setBounds(640,230,50,50);
        add(lblRowC);
        
        lblRowD = new JLabel();
        lblRowD.setText("D");
        lblRowD.setBounds(640,290,50,50);
        add(lblRowD);
        
        lblRowE = new JLabel();
        lblRowE.setText("E");
        lblRowE.setBounds(640,320,50,50);
        add(lblRowE);
        
        lblRowF = new JLabel();
        lblRowF.setText("F");
        lblRowF.setBounds(640,350,50,50);
        add(lblRowF);
        
        lblRowG = new JLabel();
        lblRowG.setText("G");
        lblRowG.setBounds(640,410,50,50);
        add(lblRowG);
        
        lblRowH = new JLabel();
        lblRowH.setText("H");
        lblRowH.setBounds(640,440,50,50);
        add(lblRowH);
                
        lblRowI = new JLabel();
        lblRowI.setText("I");
        lblRowI.setBounds(640,470,50,50);
        add(lblRowI);
        
               
        GoldSeats = new JPanel();
        GoldSeats.setBounds(90,185,600,100);
        SilverSeats = new JPanel();
        SilverSeats.setBounds(90,305,600,100);
        BronzeSeats = new JPanel();
        BronzeSeats.setBounds(90,425,600,100);
        
        buttons = new JButton[btn_count/30][btn_count/3]; //initialising the array//initialising the array
            
        for(int i = 0; i < 3; i++){ //setting a for loop for the 3 colours
            for(int j = 0; j < 30; j++){ // for loop for 30 buttons
                
                buttons[i][j] = new JButton();

                        if(i == 0){

                            l = j + 1;
                         
                            
                            buttons[0][j].setBackground(new java.awt.Color(204, 153, 0));
                            buttons[0][j].setForeground(new java.awt.Color(0,0,0));
                            buttons[0][j].setText(Integer.toString(l));
                            //gold.setText(String.valueOf(buttons[i][j]));
                            experimentLayout =  new GridLayout(3,10);
                            experimentLayout.setVgap(10);
                            experimentLayout.setHgap(10);
                            GoldSeats.setLayout(experimentLayout);
                            GoldSeats.add(buttons[0][j]);
                            
                            
                            add(GoldSeats);  
                            
                            buttons[0][j].addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                                {
                                    
                                                                
                                    if(evt.getSource() ==  buttons[0][0]){
                                        
                                    txtSeat.setText("gold a1" );
                                    buttons[0][0].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][1]){
                                        
                                    txtSeat.setText("gold a2" );
                                    buttons[0][1].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][2]){
                                        
                                    txtSeat.setText("gold a3" );
                                    buttons[0][2].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][3]){
                                        
                                    txtSeat.setText("gold a4" );
                                    buttons[0][3].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][4]){
                                        
                                    txtSeat.setText("gold a5" );
                                    buttons[0][4].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][5]){
                                        
                                    txtSeat.setText("gold a6" );
                                    buttons[0][5].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][6]){
                                        
                                    txtSeat.setText("gold a7" );
                                    buttons[0][6].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][7]){
                                        
                                    txtSeat.setText("gold a8" );
                                    buttons[0][7].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][8]){
                                        
                                    txtSeat.setText("gold a9" );
                                    buttons[0][8].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][9]){
                                        
                                    txtSeat.setText("gold a10" );
                                    buttons[0][9].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][10]){
                                        
                                    txtSeat.setText("gold b11" );
                                    buttons[0][10].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][11]){
                                        
                                    txtSeat.setText("gold b12" );
                                    buttons[0][11].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][12]){
                                        
                                    txtSeat.setText("gold b13" );
                                    buttons[0][12].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][13]){
                                        
                                    txtSeat.setText("gold b14" );
                                    buttons[0][13].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][14]){
                                        
                                    txtSeat.setText("gold b15" );
                                    buttons[0][14].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][15]){
                                        
                                    txtSeat.setText("gold b16" );
                                    buttons[0][15].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][16]){
                                        
                                    txtSeat.setText("gold b17" );
                                    buttons[0][16].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][17]){
                                        
                                    txtSeat.setText("gold b18" );
                                    buttons[0][17].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][18]){
                                        
                                    txtSeat.setText("gold b19" );
                                    buttons[0][18].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][19]){
                                        
                                    txtSeat.setText("gold b20" );
                                    buttons[0][19].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][20]){
                                        
                                    txtSeat.setText("gold c21" );
                                    buttons[0][20].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][21]){
                                        
                                    txtSeat.setText("gold c22" );
                                    buttons[0][21].setBackground(Color.RED);
                                    
                                    }if(evt.getSource() ==  buttons[0][22]){
                                        
                                    txtSeat.setText("gold c23" );
                                    buttons[0][22].setBackground(Color.RED);
                                    
                                    }if(evt.getSource() ==  buttons[0][23]){
                                        
                                    txtSeat.setText("gold c24" );
                                    buttons[0][23].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][24]){
                                    txtSeat.setText("gold c25" );
                                    buttons[0][24].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][25]){
                                        
                                    txtSeat.setText("gold c26" );
                                    buttons[0][25].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][26]){
                                        
                                    txtSeat.setText("gold c27" );
                                    buttons[0][26].setBackground(Color.RED);
                                    
                                    }if(evt.getSource() ==  buttons[0][27]){
                                        
                                    txtSeat.setText("gold c28" );
                                    buttons[0][27].setBackground(Color.RED);
                                    
                                    }if(evt.getSource() ==  buttons[0][28]){
                                        
                                    txtSeat.setText("gold c29" );
                                    buttons[0][28].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[0][29]){
                                        
                                    txtSeat.setText("gold c30" );
                                    buttons[0][29].setBackground(Color.RED);
                                    
                                    }

                                }
            
                                
        
                            });
                        }
                        
                        else if (i == 1){

                        
                            l = j + 1;
                            
                            
                            buttons[1][j].setBackground(new java.awt.Color(153, 153, 153));
                            buttons[1][j].setForeground(new java.awt.Color(0,0,0));
                            buttons[1][j].setText(Integer.toString(l));
                            
                            //gold.setText(String.valueOf(buttons[i][j]));
                            experimentLayout =  new GridLayout(3,10);
                            experimentLayout.setVgap(10);
                            experimentLayout.setHgap(10);
                           SilverSeats.setLayout(experimentLayout);
                           SilverSeats.add(buttons[1][j]);
                            
                            
                            add(SilverSeats);  
                            
                            
                            buttons[1][j].addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                                {
                                    if(evt.getSource() ==  buttons[1][0]){
                                        
                                    txtSeat.setText("silver d1" );
                                    buttons[1][0].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][1]){
                                        
                                    txtSeat.setText("silver d2" );
                                    buttons[1][1].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][2]){
                                        
                                    txtSeat.setText("silver d3" );
                                    buttons[1][2].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][3]){
                                        
                                    txtSeat.setText("silver d4" );
                                    buttons[1][3].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][4]){
                                        
                                    txtSeat.setText("silver d5" );
                                    buttons[1][4].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][5]){
                                        
                                    txtSeat.setText("silver d6" );
                                    buttons[1][5].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][6]){
                                        
                                    txtSeat.setText("silver d7" );
                                    buttons[1][6].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][7]){
                                        
                                    txtSeat.setText("silver d8" );
                                    buttons[1][7].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][8]){
                                        
                                    txtSeat.setText("silver d9" );
                                    buttons[1][8].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][9]){
                                        
                                    txtSeat.setText("silver d10" );
                                    buttons[1][9].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][10]){
                                        
                                    txtSeat.setText("silver e11" );
                                    buttons[1][10].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][11]){
                                        
                                    txtSeat.setText("silver e12" );
                                    buttons[1][11].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][12]){
                                        
                                    txtSeat.setText("silver e13" );
                                    buttons[1][12].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][13]){
                                        
                                    txtSeat.setText("silver e14" );
                                    buttons[1][13].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][14]){
                                        
                                    txtSeat.setText("silver e15" );
                                    buttons[1][14].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][15]){
                                        
                                    txtSeat.setText("silver e16" );
                                    buttons[1][15].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][16]){
                                        
                                    txtSeat.setText("silver e17" );
                                    buttons[1][16].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][17]){
                                        
                                    txtSeat.setText("silver e18" );
                                    buttons[1][17].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][18]){
                                        
                                    txtSeat.setText("silver e19" );
                                    buttons[1][18].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][19]){
                                        
                                    txtSeat.setText("silver e20" );
                                    buttons[1][19].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][20]){
                                        
                                    txtSeat.setText("silver f21" );
                                    buttons[1][20].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][21]){
                                        
                                    txtSeat.setText("silver f22" );
                                    buttons[1][21].setBackground(Color.RED);
                                    
                                    }if(evt.getSource() ==  buttons[1][22]){
                                        
                                    txtSeat.setText("silver f23" );
                                    buttons[1][22].setBackground(Color.RED);
                                    
                                    }if(evt.getSource() ==  buttons[1][23]){
                                        
                                    txtSeat.setText("silver f24" );
                                    buttons[1][23].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][24]){
                                        
                                    txtSeat.setText("silver f25" );
                                    buttons[1][24].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][25]){
                                        
                                    txtSeat.setText("silver f26" );
                                    buttons[1][25].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][26]){
                                        
                                    txtSeat.setText("silver f27" );
                                    buttons[1][26].setBackground(Color.RED);
                                    
                                    }if(evt.getSource() ==  buttons[1][27]){
                                        
                                    txtSeat.setText("silver f28" );
                                    buttons[1][27].setBackground(Color.RED);
                                    
                                    }if(evt.getSource() ==  buttons[1][28]){
                                        
                                    txtSeat.setText("silver f29" );
                                    buttons[1][28].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[1][29]){
                                        
                                    txtSeat.setText("silver f30" );
                                    buttons[1][29].setBackground(Color.RED);
                                    
                                    }
                                }
        
                            });
                        }
                        else
                        
                            if(i == 2){
                
                            l = j + 1;
                            buttons[2][j].setBackground(new java.awt.Color(153, 51, 0));
                            buttons[2][j].setForeground(new java.awt.Color(0,0,0));
                            BronzeSeats.setLayout(experimentLayout);
                            BronzeSeats.add(buttons[2][j]);
                            add(BronzeSeats);
                            //bronze = buttons[2][j].;
                            buttons[2][j].setText(Integer.toString(l));
                           
                           
                            buttons[2][j].addActionListener(new java.awt.event.ActionListener() {
                            public void actionPerformed(java.awt.event.ActionEvent evt)
                                {
                                    
                                 
                                    if(evt.getSource() ==  buttons[2][0]){
                                        
                                    txtSeat.setText("Bronze g1" );
                                    buttons[2][0].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][1]){
                                        
                                    txtSeat.setText("Bronze g2" );
                                    buttons[2][1].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][2]){
                                        
                                    txtSeat.setText("Bronze g3" );
                                    buttons[2][2].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][3]){
                                        
                                    txtSeat.setText("Bronze g4" );
                                    buttons[2][3].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][4]){
                                        
                                    txtSeat.setText("Bronze g5" );
                                    buttons[2][4].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][5]){
                                        
                                    txtSeat.setText("Bronze g6" );
                                    buttons[2][5].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][6]){
                                        
                                    txtSeat.setText("Bronze g7" );
                                    buttons[2][6].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][7]){
                                        
                                    txtSeat.setText("Bronze g8" );
                                    buttons[2][7].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][8]){
                                        
                                    txtSeat.setText("Bronze g9" );
                                    buttons[2][8].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][9]){
                                        
                                    txtSeat.setText("Bronze g10" );
                                    buttons[2][9].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][10]){
                                        
                                    txtSeat.setText("Bronze h11" );
                                    buttons[2][10].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][11]){
                                        
                                    txtSeat.setText("Bronze h12" );
                                    buttons[2][11].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][12]){
                                        
                                    txtSeat.setText("Bronze h13" );
                                    buttons[2][12].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][13]){
                                        
                                    txtSeat.setText("Bronze h14" );
                                    buttons[2][13].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][14]){
                                        
                                    txtSeat.setText("Bronze h15" );
                                    buttons[2][14].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][15]){
                                        
                                    txtSeat.setText("Bronze h16" );
                                    buttons[2][15].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][16]){
                                        
                                    txtSeat.setText("Bronze h17" );
                                    buttons[2][16].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][17]){
                                        
                                    txtSeat.setText("Bronze h18" );
                                    buttons[2][17].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][18]){
                                        
                                    txtSeat.setText("Bronze h19" );
                                    buttons[2][18].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][19]){
                                        
                                    txtSeat.setText("Bronze h20" );
                                    buttons[2][19].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][20]){
                                        
                                    txtSeat.setText("Bronze i21" );
                                    buttons[2][20].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][21]){
                                        
                                    txtSeat.setText("Bronze i22" );
                                    buttons[2][21].setBackground(Color.RED);
                                    
                                    }if(evt.getSource() ==  buttons[2][22]){
                                        
                                    txtSeat.setText("Bronze i23" );
                                    buttons[2][22].setBackground(Color.RED);
                                    
                                    }if(evt.getSource() ==  buttons[2][23]){
                                        
                                    txtSeat.setText("Bronze i24" );
                                    buttons[2][23].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][24]){
                                        
                                    txtSeat.setText("Bronze i25" );
                                    buttons[2][24].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][25]){
                                        
                                    txtSeat.setText("Bronze i26" );
                                    buttons[2][25].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][26]){
                                        
                                    txtSeat.setText("Bronze i27" );
                                    buttons[2][26].setBackground(Color.RED);
                                    
                                    }if(evt.getSource() ==  buttons[2][27]){
                                        
                                    txtSeat.setText("Bronze i28" );
                                    buttons[2][27].setBackground(Color.RED);
                                    
                                    }if(evt.getSource() ==  buttons[2][28]){
                                        
                                    txtSeat.setText("Bronze i29" );
                                    buttons[2][28].setBackground(Color.RED);
                                    
                                    }
                                    if(evt.getSource() ==  buttons[2][29]){
                                        
                                    txtSeat.setText("Bronze i30" );
                                    buttons[2][29].setBackground(Color.RED);
                                    
                                    }
                                    
                                    
                                    
            
                                }
        
                            });
                        }
                
                        buttons[i][j].setOpaque(true);
                
                       
                 
            }  
        }   
    }
    

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        
          if(e.getSource() == btnSave)
        
          {
           
          
              id = "";
              name = "";
              date = "";
              
              concert = "";
              time = "";
            
             id = txtID.getText().trim();
             name = txtName.getText().trim();
             seat = txtSeat.getText().trim(); 
             date = txtDate.getText().trim();
             concert = txtConcert.getText().trim();
             time = txtTime.getText().trim();
             summary = ("ID:"+(id)+ " Name:"+(name)+ " Seat:" +(getSeat)+" Concert:"+(concert)+ " Date:"+(date)+" Time:"+(time));
             String Data = Events.summary;
             
              
            
            try
            {    
                BufferedWriter reader = new BufferedWriter(new FileWriter(new File ("\\GUINewConcert\\src\\addbooking\\customerdetails.txt"), true));
                reader.write(Data);
                reader.newLine();
                reader.close();            
            }
            catch(IOException E)
            {
                System.out.print("Error, could not add booking");
            }
            
            String seatColour;
            String bronzePopUp = "You have booked a bronze ticket!";
            String silverPopUp = "You have been given a free brochure!";
            String seat = txtSeat.getText();
            if(seat.contains("bronze"))
            {
                seatColour = "bronze";
                JOptionPane.showMessageDialog(null, bronzePopUp);
            }
            if(seat.contains("silver"))
            {
                seatColour = "silver";
                JOptionPane.showMessageDialog(null, silverPopUp);
            }
            if(seat.contains("gold"))
            {
                seatColour = "gold";
                Percentage VIP = new Percentage();
                
                int numberOfSeats = 1;
                String goldPopUp = "You have been entered into VIP!";
                
                for(int i = 0; i < numberOfSeats; i++) //loop to perform the algorithm on all seats in the booking
                {
                    Percentage vip = new Percentage(); //new percentage object
                    vip.calcPercentage(); //calling the method to calculate the percentage
                    char VIPresult = vip.percentage(); //setting result variable to either Y or N
                    
                    if(VIPresult == 'Y') //if the result variable has been set to Y
                    {
                        JOptionPane.showMessageDialog(null, goldPopUp); //customer is added to vip area
                    }
                }
            
        }
          } 
    }
    

     public void seatActionPerformed(ActionEvent ev)
    {
        if(ev.getSource() == btnSeatsBooked)
        {
            String IDentered = JOptionPane.showInputDialog("Enter ID:");
        }
    }
    
    public void IDactionPerformed(ActionEvent ev)
    {
        if(ev.getSource() == btnID)
        {
            String path = "\\GUINewConcert\\src\\addbooking\\customerdetails.txt";
            String IDentered = JOptionPane.showInputDialog("Enter ID:");
            try
            {
                BufferedReader reader = new BufferedReader(new FileReader(path));
                String line = null;
                while((line = reader.readLine()) != null)
                {
                    if(line.contains(IDentered))
                    {
                        System.out.println(line);
                        JOptionPane.showMessageDialog(null, line);
                    }
                }
                reader.close();
            }
            catch(Exception exce)
            {
                System.out.println("Error, could not retrieve records");
            }
        }
    }
   
}