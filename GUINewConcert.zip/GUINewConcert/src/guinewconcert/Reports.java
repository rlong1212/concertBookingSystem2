
package guinewconcert;

import javax.swing.JPanel;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.*;
import java.awt.event.*;

public class Reports extends JPanel {
    
    JLabel lblReport;
    
    public Reports(){
        
        lblReport = new JLabel();
        lblReport.setText("Please select what you would like your report to be based upon:");
        add(lblReport);
    }
}
