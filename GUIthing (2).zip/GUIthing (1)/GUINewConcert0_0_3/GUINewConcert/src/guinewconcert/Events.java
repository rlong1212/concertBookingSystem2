package guinewconcert;

import com.sun.org.apache.bcel.internal.generic.Select;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTabbedPane;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JPasswordField;
import java.awt.BorderLayout;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.BoxLayout;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import javax.swing.JFormattedTextField;

public class Events extends JPanel implements ActionListener
{
    private JTabbedPane TabbedPane;
    private JButton btnAddEvent;
    private JButton btnExistingEvent;
    private JTextField txtDate;
    private JLabel errormessage;
    private JTextField txtHour;
    private JTextField txtMins;
    private JLabel jLabel1;
    private JList<String> lstExisting;
    private JScrollPane jScrollPane1;
    private JLabel lblBronzeprice;
    private JLabel lblComplete;
    private JLabel lblEventDT;
    private JLabel lblEventName;
    private JLabel lblEventTime;
    private JLabel lblGoldprice;
    private JLabel lblPrices;
    private JLabel lblSilverprice;
    private JPanel tabCreate;
    private JPanel tabExisting;
    private JPanel tabBooking;
    private JTextField txtBronzeprice;
    private JTextField txtEventName;
    private JTextField txtGoldprice;
    private JFormattedTextField txtSilverprice;
    public String name, day, month, year, hour, min, gold, silver, bronze;
    static String summary;
   GUINewConcert myframe;
    
    public Events()   
    {    
        setLayout(null);
        TabbedPane = new JTabbedPane();
        TabbedPane.setBounds(70,50,1200,650);
        tabCreate = new JPanel();
        lblGoldprice = new JLabel();
        lblEventName = new JLabel();
        txtGoldprice = new JFormattedTextField();
        txtEventName = new JTextField();
        lblSilverprice = new JLabel();
        lblEventDT = new JLabel();
        txtSilverprice = new JFormattedTextField();
        txtDate = new JTextField();
        lblBronzeprice = new JLabel();
        txtBronzeprice = new JFormattedTextField();
        
        
        
        btnAddEvent = new JButton();
        lblEventTime = new JLabel();
        lblComplete = new JLabel();
        txtHour = new JTextField();
        txtMins = new JTextField();
        lblPrices = new JLabel();
        tabExisting = new JPanel();
        jScrollPane1 = new JScrollPane();
        lstExisting = new JList<>();
        btnExistingEvent = new JButton();
        jLabel1 = new JLabel();
        tabBooking = new JPanel();
        errormessage = new JLabel();
        
        lblGoldprice.setText("Gold: ");
        lblGoldprice.setToolTipText("");
        lblEventName.setText("Event Title:  ");
        txtGoldprice.setColumns(5);
        txtGoldprice.setText("£");
        txtEventName.setColumns(30);
        lblSilverprice.setText("Silver: ");
        lblEventDT.setText("Event Date: ");
        txtSilverprice.setColumns(5);
        txtSilverprice.setText("£");
        txtDate.setText("eg. 01/01/17");
        errormessage.setText("Please enter correct date format eg. 01/01/17");
        
        txtGoldprice.addKeyListener(new KeyAdapter() {
    public void keyTyped(KeyEvent e) {
      char c = e.getKeyChar();
      if (!((c >= '0') && (c <= '9')||
         (c == KeyEvent.VK_BACK_SPACE) ||
         (c == KeyEvent.VK_DELETE))) {
        getToolkit().beep();
        e.consume();
      }
    }
  });
        
        
        txtSilverprice.addKeyListener(new KeyAdapter() {
    public void keyTyped(KeyEvent e) {
      char c = e.getKeyChar();
      if (!((c >= '0') && (c <= '9') ||
         (c == KeyEvent.VK_BACK_SPACE) ||
         (c == KeyEvent.VK_DELETE))) {
        getToolkit().beep();
        e.consume();
      }
    }
  });
        
        
        txtBronzeprice.addKeyListener(new KeyAdapter() {
    public void keyTyped(KeyEvent e) {
      char c = e.getKeyChar();
      if (!((c >= '0') && (c <= '9') ||
         (c == KeyEvent.VK_BACK_SPACE) ||
         (c == KeyEvent.VK_DELETE))) {
        getToolkit().beep();
        e.consume();
      }
    }
  });
        
        txtHour.setColumns(2);
        txtHour.addKeyListener(new KeyAdapter() {
    public void keyTyped(KeyEvent e) {
      char c = e.getKeyChar();
      if (!((c >= '0') && (c <= '9') ||
         (c == KeyEvent.VK_BACK_SPACE) ||
         (c == KeyEvent.VK_DELETE))) {
        getToolkit().beep();
        e.consume();
      }
    }
  });
        
        
        txtDate.setColumns(8);
        
        txtMins.setColumns(2);
        txtMins.addKeyListener(new KeyAdapter() {
    public void keyTyped(KeyEvent e) {
      char c = e.getKeyChar();
      if (!((c >= '0') && (c <= '9') ||
         (c == KeyEvent.VK_BACK_SPACE) ||
         (c == KeyEvent.VK_DELETE))) {
        getToolkit().beep();
        e.consume();
      }
    }
  });
        
        lblBronzeprice.setText("Bronze: ");
        
        txtBronzeprice.setColumns(5);
        txtBronzeprice.setText("£");
        
        
        btnAddEvent.setText("Add Event");
        btnAddEvent.addActionListener(this);
        lblEventTime.setText("Event Time: ");
        lblComplete.setFont(new java.awt.Font("Tahoma", 0, 14)); 
        lblComplete.setText("Please complete the form below to create an event.");
        lblPrices.setFont(new java.awt.Font("Tahoma", 1, 14)); 
        lblPrices.setText("Seating Prices");
        
        lstExisting.setModel(new javax.swing.AbstractListModel<String>() 
        {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        
        jScrollPane1.setViewportView(lstExisting);
        btnExistingEvent.setText("Select Event");
        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 16)); 
        jLabel1.setText("Please select whether you are creating a new event or an existing event: ");
        TabbedPane.getAccessibleContext().setAccessibleName("Create new event");
        TabbedPane.addTab("Create New Booking", tabBooking);
        tabBooking.add(new Seats());
        TabbedPane.getAccessibleContext().setAccessibleName("Create New Booking");
        
        add(jLabel1); //adding components to the JPanel
        add(TabbedPane);
      
        TabbedPane.addTab("Create new event", tabCreate); //adding tabs to the tabbed pane
        TabbedPane.addTab("Exisiting Event", tabExisting);
        TabbedPane.addTab("Create New Booking", tabBooking);
        tabBooking.setLayout(new BoxLayout(tabBooking, BoxLayout.LINE_AXIS));
        
        tabCreate.add(lblComplete); //adding components to the Create new event tab on 
        tabCreate.add(lblEventName);
        tabCreate.add(txtEventName);
        tabCreate.add(lblEventDT);  
        tabCreate.add(txtDate);
        tabCreate.add(lblEventTime);
        tabCreate.add(txtHour);
        tabCreate.add(txtMins);
        tabCreate.add(lblPrices);
        tabCreate.add(lblGoldprice);
        tabCreate.add(txtGoldprice);
        tabCreate.add(lblSilverprice);
        tabCreate.add(txtSilverprice);
        tabCreate.add(lblBronzeprice);
        tabCreate.add(txtBronzeprice);
        tabCreate.add(btnAddEvent);
        
        tabExisting.add(lstExisting); //adding components to the Existing tab
        tabExisting.add(jScrollPane1);
        tabExisting.add(btnExistingEvent); 
        
       }

    @Override
    public void actionPerformed(ActionEvent e) 
    {    
        //this.setVisible(false);
          if(e.getSource() == btnAddEvent)
             
          {
              name =("");
              day = ("");
              hour = ("");
              gold = ("");
              silver = ("");
              bronze = ("");
            
              name = txtEventName.getText().trim();
              day = txtDate.getText().toString().trim();
              hour = txtHour.getText().toString().trim();
              gold = txtGoldprice.getText().trim();
              silver = txtSilverprice.getText().trim();
              bronze = txtBronzeprice.getText().trim();
              summary = ("Name:"+(name)+ "\nDay:"+(day)+ "\nMonth:" +(month)+ "\nYear:"+(year)+ "\nHour:"+(hour)+"\nMins:"+(min)+ "\nGold seat:"+(gold)+ "\nSilver seat:" +(silver)+ "\nBronze seat:"+(bronze));
              
                          
               
              
              String Data = Events.summary;
            
              try
              {
                 
                  
                  FileWriter writer = new FileWriter("C:\\Users\\Shannon\\Desktop\\GUIthing (1)\\GUINewConcert0_0_3\\GUINewConcert\\src\\addevent\\NewEvernt.txt");
                  writer.write(Data);
                  writer.close();
              }
              catch(IOException E)
              {
                  System.out.print("Error, could not add event");
              }
          }
    }
}