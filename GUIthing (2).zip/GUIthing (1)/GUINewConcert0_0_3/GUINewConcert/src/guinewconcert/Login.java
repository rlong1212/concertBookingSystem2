package guinewconcert;

import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.BorderLayout;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JFrame;

public class Login extends JPanel implements ActionListener
{
    String username = "Admin123"; 
    String pass = "Passw0rd";
    String msg =" ";
    //GUINewConcert myframe; 
    
    private javax.swing.JButton btnlogin; //declaring components
    private javax.swing.JLabel lblwelcome;
    private javax.swing.JLabel lblpassword;
    private javax.swing.JLabel lblusername;
    private javax.swing.JPasswordField txtpassword;
    private javax.swing.JTextField txtusername;
    
    public Login()
    {
        this.setLayout(null);
        
        lblwelcome = new javax.swing.JLabel(); //creating new instance      
        lblwelcome.setFont(new java.awt.Font("Arial", 0, 14)); // Setting labels font and size
        lblwelcome.setText("Welcome! Please enter your details to continue."); // Setting the text to be displayed
        lblwelcome.setBounds(50,50,550,50);
        
        lblusername = new javax.swing.JLabel();
        lblusername.setFont(new java.awt.Font("Arial", 0, 14)); 
        lblusername.setText("Username: ");
        lblusername.setBounds(70,100,150,50);
                
        lblpassword = new javax.swing.JLabel();
        lblpassword.setFont(new java.awt.Font("Arial", 0, 14)); 
        lblpassword.setText("Password: ");
        lblpassword.setBounds(70,150,150,50);

        txtusername = new javax.swing.JTextField();
        txtusername.setColumns(10); //declaring how many characters can be entered
        txtusername.setBounds(160,110,250,30);
        
        txtpassword = new javax.swing.JPasswordField();
        txtpassword.setColumns(10);
        txtpassword.setBounds(160,160,250,30);
        
        btnlogin = new javax.swing.JButton();
        btnlogin.setText("Login");
        btnlogin.addActionListener(this); //adding an actionlistener to the login button
        btnlogin.setBounds(310,220,100,25);
        
        add(lblwelcome,BorderLayout.NORTH); //adding components to the JPanel
        add(lblusername,BorderLayout.CENTER);
        add(txtusername,BorderLayout.CENTER);
        add(lblpassword,BorderLayout.CENTER);
        add(txtpassword,BorderLayout.CENTER);
        add(btnlogin,BorderLayout.CENTER);
        
    }
               private void btnloginkeyPressed(KeyEvent evt)
            {
                if(evt.getKeyCode() == KeyEvent.VK_ENTER)
                {
                    if(username.equals(txtusername.getText()))
        {
                if(pass.equals(txtpassword.getText())) //if statement to check if username and password are correct
                {
                   this.add(new Events());
                   
                   GUINewConcert frame1 = new GUINewConcert();
                   frame1.setLayout(new BorderLayout());
                   frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                   frame1.setResizable(false);
                   frame1.setLocationRelativeTo(null);        
                   frame1.setVisible(true); //shows the JPanel
                   frame1.setSize(1600,800); //sets JPanel Size
                   frame1.add(new Events()); //adding the Events JPanel to the JFrame
                   msg = "";
                   this.setVisible(false); //hides the Login JPanel*/
                }
                else
                {
                    msg = "Login Denied";
                    JOptionPane.showMessageDialog(null,msg);
                }
        }
        else       
        {       
            msg = "Login Denied";
            JOptionPane.showMessageDialog(null,msg);
        }
     
                }
            }

        
 
    @Override
    public void actionPerformed(ActionEvent e) 
    {
        if(username.equals(txtusername.getText()))
        {
                if(pass.equals(txtpassword.getText())) //if statement to check if username and password are correct
                {
                   this.add(new Events());
                   
                   GUINewConcert frame1 = new GUINewConcert();
                   frame1.setLayout(new BorderLayout());
                   frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                   frame1.setResizable(false);
                   frame1.setLocationRelativeTo(null);        
                   frame1.setVisible(true); //shows the JPanel
                   frame1.setSize(1600,800); //sets JPanel Size
                   frame1.add(new Events()); //adding the Events JPanel to the JFrame
                   msg = "";
                   this.setVisible(false); //hides the Login JPanel*/
                }
                else
                {
                    msg = "Login Denied";
                    JOptionPane.showMessageDialog(null,msg);
                }
        }
        else       
        {       
            msg = "Login Denied";
            JOptionPane.showMessageDialog(null,msg);
        }
    }
}