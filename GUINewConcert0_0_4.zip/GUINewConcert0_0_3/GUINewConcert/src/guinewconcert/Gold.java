public class Gold 
{
    
}
