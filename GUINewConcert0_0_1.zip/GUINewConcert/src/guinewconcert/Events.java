package guinewconcert;

import com.sun.org.apache.bcel.internal.generic.Select;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTabbedPane;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JPasswordField;
import java.awt.BorderLayout;
import java.awt.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class Events extends JPanel implements ActionListener{
    
    private JTabbedPane TabbedPane;
    private JButton btnAddEvent;
    private JButton btnExistingEvent;
    private JComboBox<String> cbxDay;
    private JComboBox<String> cbxHour;
    private JComboBox<String> cbxMonth;
    private JComboBox<String> cbxYear;
    private JComboBox<String> cbxMins;
    private JLabel jLabel1;
    private JList<String> lstExisting;
    private JScrollPane jScrollPane1;
    private JLabel lblBronzeprice;
    private JLabel lblComplete;
    private JLabel lblEventDT;
    private JLabel lblEventName;
    private JLabel lblEventTime;
    private JLabel lblGoldprice;
    private JLabel lblPrices;
    private JLabel lblSilverprice;
    private JPanel tabCreate;
    private JPanel tabExisting;
    private JPanel tabBooking;
    private JTextField txtBronzeprice;
    private JTextField txtEventName;
    private JTextField txtGoldprice;
    private JTextField txtSilverprice;
    public String name, day, month, year, hour, min, gold, silver, bronze;

    static String summary;

    
    GUINewConcert myframe;
    
    public Events()
            
    {                
        
        setLayout(null);
        
        TabbedPane = new JTabbedPane();
        TabbedPane.setBounds(70,100,1200,500);
        tabCreate = new JPanel();
        lblGoldprice = new JLabel();
        lblEventName = new JLabel();
        txtGoldprice = new JTextField();
        txtEventName = new JTextField();
        lblSilverprice = new JLabel();
        lblEventDT = new JLabel();
        txtSilverprice = new JTextField();
        cbxDay = new JComboBox<>();
        lblBronzeprice = new JLabel();
        cbxMonth = new JComboBox<>();
        txtBronzeprice = new JTextField();
        cbxYear = new JComboBox<>();
        btnAddEvent = new JButton();
        lblEventTime = new JLabel();
        lblComplete = new JLabel();
        cbxHour = new JComboBox<>();
        cbxMins = new JComboBox<>();
        lblPrices = new JLabel();
        tabExisting = new JPanel();
        jScrollPane1 = new JScrollPane();
        lstExisting = new JList<>();
        btnExistingEvent = new JButton();
        jLabel1 = new JLabel();
        tabBooking = new JPanel();

        lblGoldprice.setText("Gold: ");
        lblGoldprice.setToolTipText("");

        lblEventName.setText("Event Title:  ");

        txtGoldprice.setColumns(5);
        txtGoldprice.setText("£");

        txtEventName.setColumns(30);

        lblSilverprice.setText("Silver: ");

        lblEventDT.setText("Event Date: ");

        txtSilverprice.setColumns(5);
        txtSilverprice.setText("£");

        cbxDay.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" }));

        lblBronzeprice.setText("Bronze: ");

        cbxMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" }));

        txtBronzeprice.setColumns(5);
        txtBronzeprice.setText("£");

        cbxYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "2016", "2017", "2018" }));

        btnAddEvent.setText("Add Event");
        btnAddEvent.addActionListener(this);

        lblEventTime.setText("Event Time: ");

        lblComplete.setFont(new java.awt.Font("Tahoma", 0, 14)); 
        lblComplete.setText("Please complete the form below to create an event.");

        cbxHour.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "00" }));

        cbxMins.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "00", "05", "10", "15", "20", "25", "30", "35", "40", "45", "50", "55" }));

        lblPrices.setFont(new java.awt.Font("Tahoma", 1, 14)); 
        lblPrices.setText("Seating Prices");
        
         TabbedPane.addTab("Create new event", tabCreate);
        
        lstExisting.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(lstExisting);

        btnExistingEvent.setText("Select Event");
        
        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 16)); 
        jLabel1.setText("Please select whether you are creating a new event or an existing event: ");
        
        
        TabbedPane.getAccessibleContext().setAccessibleName("Create new event");
    
        
        add(jLabel1); //adding components to the JPanel
        add(TabbedPane, BorderLayout.CENTER);
      
        TabbedPane.addTab("Create new event", tabCreate); //adding tabs to the tabbed pane
        TabbedPane.addTab("Exisiting Event", tabExisting);
        TabbedPane.addTab("Create New Booking", tabBooking);
       
        tabCreate.add(lblComplete); //adding components to the Create new event tab on 
        tabCreate.add(lblEventName);
        tabCreate.add(txtEventName);
        tabCreate.add(lblEventDT);  
        tabCreate.add(cbxDay);
        tabCreate.add(cbxYear);
        tabCreate.add(cbxMonth);
        tabCreate.add(lblEventTime);
        tabCreate.add(cbxHour);
        tabCreate.add(cbxMins);
        tabCreate.add(lblPrices);
        tabCreate.add(lblGoldprice);
        tabCreate.add(txtGoldprice);
        tabCreate.add(lblSilverprice);
        tabCreate.add(txtSilverprice);
        tabCreate.add(lblBronzeprice);
        tabCreate.add(txtBronzeprice);
        tabCreate.add(btnAddEvent);
        
        tabExisting.add(lstExisting); //adding components to the Existing tab
        tabExisting.add(jScrollPane1);
        tabExisting.add(btnExistingEvent); 
       
        
        
        
       }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        this.setVisible(false);
        
          if(e.getSource() == btnAddEvent){
            
            name =("");
            day = ("");
            month=("");
            year=("");
            hour = ("");
            gold = ("");
            silver = ("");
            bronze = ("");
            
            name = txtEventName.getText().trim();
            day = cbxDay.getSelectedItem().toString().trim();
            month = cbxMonth.getSelectedItem().toString().trim();
            year = cbxYear.getSelectedItem().toString().trim();
            hour = cbxHour.getSelectedItem().toString().trim();
            gold = txtGoldprice.getText().trim();
            silver = txtSilverprice.getText().trim();
            bronze = txtBronzeprice.getText().trim();
            summary = ("name: "+(name)+ "\\nday: "+(day)+ "\\nmonth:" +(month)+ "\\nyear:"+(year)+ "\\nhour:"+(hour)+"\\nmins: "+(min)+ "\\ngold seat: "+(gold)+ "\\nSilver seat: " +(silver)+ "\\nBronze seat: "+(bronze));
            String Data = Events.summary;
            
            try{
                
            BufferedWriter reader = new BufferedWriter(new FileWriter(new File ("C:\\Users\\Lauraaa\\Desktop\\GUINewConcert\\src\\addevent\\"+(name)+".txt"), true));
            reader.write(Data);
            reader.newLine();
            reader.close();
            
            }
            catch(IOException E)
                    {
                        System.out.print("Error is" + E);
           
                    }
            
    }
    

    }
}

