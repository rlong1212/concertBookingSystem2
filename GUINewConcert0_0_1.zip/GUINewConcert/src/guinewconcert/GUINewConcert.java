package guinewconcert;

import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;


public class GUINewConcert extends JFrame{
    
    JMenuBar theMenuBar;
    JMenu theMenu;
    JMenuItem reportItem;
    JMenuItem exitItem;
    

    public GUINewConcert()
    {
        theMenuBar = new JMenuBar(); 
                
        theMenu = new JMenu();
        theMenu.setText("File"); //setting the text of the menu
        
        reportItem = new JMenuItem();
        reportItem.setText("Reports");
         reportItem.addActionListener(new java.awt.event.ActionListener() { //adding an actionlistener to the report JMenuItem
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reportItemItemActionPerformed(evt);
            }

        });
        
        
        exitItem = new JMenuItem();
        exitItem.setText("Exit");
        exitItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitItemActionPerformed(evt);
            }
        });
        
        theMenu.add(reportItem); //adding menu item to the menu
        theMenu.add(exitItem);
        
        theMenuBar.add(theMenu); //adding the menu to the menu bar
       
        setJMenuBar(theMenuBar);
        
    }
    private void exitItemActionPerformed(java.awt.event.ActionEvent evt) {                                          
        
            JOptionPane.showMessageDialog ( null, "You are about to exit the application"); //display a message
            System.exit(0); // Exit application
    }        
    
     private void reportItemItemActionPerformed(ActionEvent evt) {
             
         GUINewConcert frame = new GUINewConcert();
         frame.setLayout(new BorderLayout());
         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         frame.setSize(500,500);
         frame.add(new Reports());
         frame.setResizable(false);
         frame.setLocationRelativeTo(null);
         frame.setVisible(true); 
         
     }
           
    
    public static void main(String[] args) 
    {
        
        GUINewConcert myframe = new GUINewConcert();
        myframe.setLayout(new BorderLayout()); //seting the JFrames layout manager
        myframe.setTitle("Booking System"); // sets name on title bar
        myframe.setSize(500,400); // sets the size of the frame
        myframe.setLocationRelativeTo(null); // Centers GUI frame
        myframe.setDefaultCloseOperation(GUINewConcert.EXIT_ON_CLOSE); // Stop/Close program on exit 
        myframe.add(new Login());
        myframe.setVisible(true);// shows the frame
        
    }
    
}
