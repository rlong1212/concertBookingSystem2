
package guinewconcert;

import javax.swing.JPanel;
import java.awt.event.ActionEvent;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.*;
import java.awt.event.*;

public class Reports extends JPanel 
{
    JLabel lblReport;
    JRadioButton rdoSeatQuery;
    JRadioButton rdoSeatsBooked;
    JButton btnGenerate;
    
    public Reports()
    {
        lblReport = new JLabel();
        lblReport.setText("Please select what you would like your report to be based upon:");
        add(lblReport);
        
        rdoSeatQuery = new JRadioButton();
        rdoSeatQuery.setText("Query Seating");
        add(rdoSeatQuery);
        
        rdoSeatsBooked = new JRadioButton();
        rdoSeatsBooked.setText("How many seats have been booked");
        add(rdoSeatsBooked);
        
        btnGenerate = new JButton();
        btnGenerate.setText("Generate Report");
        add(btnGenerate); 
    }
}
