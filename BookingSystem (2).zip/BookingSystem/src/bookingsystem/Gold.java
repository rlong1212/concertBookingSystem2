package bookingsystem;

public class Gold extends BookingSystem //inheriting from BookingSystem
{
    public double goldPrice() //public method for getting the price of a gold seat
    {
        price = 20.00; //link to the txtGoldprice.text 
        return price; //returning the price to be stored and used again in the program
    }
    
}
