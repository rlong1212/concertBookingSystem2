package bookingsystem;

public class Silver extends BookingSystem //inheriting from BookingSystem
{
    public double silverPrice() //public method for getting the price of a silver seat
    {
        price = 15.00; //link to the txtSilverprice.text
        return price; //returning the price to be stored and used again in the program
    }
}
