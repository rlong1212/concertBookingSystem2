package bookingsystem;
import java.util.*;
import java.io.*;
import javax.swing.JOptionPane;
public class BookingSystem 
{
    Scanner input = new Scanner (System.in); //getting input from keyboard
    double price; //price variable to be used in child classes
    
    public static void main(String[] args)
    {
        Scanner input = new Scanner (System.in);
        System.out.print("G = Gold\nS = Silver\nB = Bronze");
        String chosenSeatColor = input.nextLine();
        
        switch(chosenSeatColor) //switch the chosen sest color
        {
            case "G": //if the color is gold..
                Gold gold = new Gold(); //new gold object created
                System.out.println("You have booked a gold seat"); 
                System.out.println("Price: £" + gold.goldPrice()); //calling the gold price from the gold class
                //loop to calculate the 10% chance of a VIP entry
                int numberOfSeats = 1; //= the number of seats drop down variable
                
                for(int i = 0; i < numberOfSeats; i++) //loop to perform the algorithm on all seats in the booking
                {
                    Percentage vip = new Percentage(); //new percentage object
                    vip.calcPercentage(); //calling the method to calculate the percentage
                    char VIPresult = vip.percentage(); //setting result variable to either Y or N
                    
                    if(VIPresult == 'Y') //if the result variable has been set to Y
                    {
                        System.out.println("You have been entered into VIP!"); //customer is added to vip area
                    }
                }
                
                break;
            case "S": //if the color is silver..
                Silver silver = new Silver(); //new silver object is created
                System.out.println("You have booked a silver seat"); 
                System.out.println("Price: £" + silver.silverPrice()); //calling the silver price from the silver class
                System.out.println("Free brochure");
                //HERE WE HAVE A FREE BROCHURE POP UP A DIALOGUE BOX
                //JOptionPane.showMessageDialog("Remember to give free brochure", silver);
                
                break;
            case "B": //if the color is bronze..
                Bronze bronze = new Bronze(); //new bronze object is created
                System.out.println("You have booked a bronze seat");
                System.out.println("Price: £" + bronze.bronzePrice()); //calling the bronze price from the bronze class
                break;
            default:
                System.out.println("Please choose a seat");
                break;
        }
        String path = "C:\\Users\\Owner\\Documents\\NetBeansProjects\\BookingSystem\\src\\bookingsystem\\file.txt"; //path to the file.txt file
        String ID = "AD17"; //entered ID to search for
        try
        {
            BufferedReader reader = new BufferedReader(new FileReader(path)); //creating a reader to read to file.txt
            String line = null; //variable to go through lines
            //while loop
            while((line = reader.readLine()) != null) //while the reader is still reading lines (stops when is null aka no more lines)
            {
                if(line.contains(ID)) //.contains used to find all lines that contain the String from ID variable
                {
                    System.out.println(line); //printing all found lines
                }
            }
            reader.close(); //closing the reader
        }
        catch(IOException e)
        {
            System.out.println("Error, cannot read file"); //error if the file cannot be found
        }

    }
}
