package bookingsystem;
import java.util.Random;
public class Percentage 
{
    int seatsBooked; //this is the number of seats in the booking
    char VIP;
    int i;
    public void calcPercentage() //method calculates the 10% chance of a VIP entry
    {
        Random rand = new Random(); //using the random method
        for(i = 0; i < 100; i++) //for loop 
        {
            int result = rand.nextInt(10) + 1; //getting random number between 1-10
            if(result <= 3) //if the result is between 1 and 3..
            {
                VIP = 'Y'; //VIP variable is set to Y (indicating yes)
            }
            else
            {
                VIP = 'N';
            }
        }
        //random num from 1-10
        //if is between 1 and 3, they win
        //loop the calc X seatsBooked
    }
    public char percentage() //public get method 
    {
        return VIP; //returning the VIP char to use again in the program
    }
}
