package bookingsystem;

public class Bronze extends BookingSystem //inheriting from BookingSystem
{
    public double bronzePrice() //public method for getting the price of a bronze seat
    {
        price = 10.00; //link to the txtBronzeprice.text
        return price; //returning the price to be stored and used again in the program
    }
}
