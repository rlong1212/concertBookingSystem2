package guinewconcert;

import static guinewconcert.Events.summary;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.GridLayout;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import javax.swing.BoxLayout;
import static javax.swing.JSplitPane.LEFT;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

public class Seats extends JPanel implements ActionListener {
    
    JLabel lblNumbers;
    JLabel lblRowA;
    JLabel lblRowB;
    JLabel lblRowC;
    JLabel lblRowD;
    JLabel lblRowE;
    JLabel lblRowF;
    JLabel lblRowG;
    JLabel lblRowH;
    JLabel lblRowI;
    
    public JButton[][] buttons; // declaring array for buttons
    public JButton gold, silver, bronze;
    public final int btn_count = 90; // declaring a counter for the array
    public JPanel BronzeSeats;
    public JPanel GoldSeats;
    public JPanel SilverSeats;
    private JLabel lblCreate, lblID, lblName, lblSeat, lblConcert, lblDate, txtSeat, lblTime;
    private JTextField txtID, txtName, txtConcert, txtDate, txtTime;
    private JButton btnSave;
    private GridLayout experimentLayout;
    public String id, name, seat, concert, date, time;
    public int number;
    static String summary;
    
    HashMap<String,JButton> buttonCache = new HashMap<String,JButton>();
    
        public void paintComponent(Graphics g){
         g.drawLine(30,50,90,50); // Draw a horizontal line line from (30,90) to (50,50)
         g.drawLine(150,50,240,50); 
         g.drawLine(240,50,240,120);
         g.drawLine(240,120,480,120);
         g.drawLine(480,120,480,50);
         g.drawLine(480,50,560,50);
         g.drawLine(620,50,680,50);
            }
        
    public Seats(){
        setLayout(null);
        
        String path = "C:\\Users\\Owner\\Desktop\\GUINewConcert0_0_3\\GUINewConcert\\src\\addevent\\NewEvernt.txt"; //path to the file
        String Name = "Name:"; //looking for the name
        try
        {
            BufferedReader reader = new BufferedReader(new FileReader(path)); //creating a reader to read to file.txt
            String line = null; //variable to go through lines
            //while loop
            while((line = reader.readLine()) != null) //while the reader is still reading lines (stops when is null aka no more lines)
            {
                if(line.contains(Name)) //.contains used to find all lines that contain the String from Name variable
                {
                    txtConcert = new JTextField(line);
                }
            }
            reader.close(); //closing the reader
        }
        catch (Exception exc)
        {
            System.out.println("Error, could not get concert name");
        }
        
        lblID = new JLabel();
        lblName = new JLabel();
        lblSeat = new JLabel();
        lblConcert = new JLabel();
        lblDate = new JLabel();
        lblTime = new JLabel();
        
        txtID = new JTextField();
        txtName = new JTextField();
        txtSeat = new JLabel();
        
        txtDate = new JTextField();
        txtTime = new JTextField();
        
        btnSave = new JButton();
        
        
        btnSave.setBounds(820, 350, 150, 50);
        
        lblID.setBounds(750, 50, 150, 50);
        lblName.setBounds(750, 100, 150, 50);
        lblSeat.setBounds(750, 150, 150, 50);
        lblDate.setBounds(750, 200, 150, 50);
        lblTime.setBounds(750, 250, 150, 50);
        lblConcert.setBounds(750, 300, 150, 50);
        
        txtID.setBounds(800, 60, 150, 25);
        txtName.setBounds(800, 110, 150, 25);
        txtSeat.setBounds(800, 160, 150, 25);
        txtDate.setBounds(800, 210, 150, 25);
        txtTime.setBounds(800, 260, 150, 25);
        txtConcert.setBounds(800, 310, 150, 25);
        
        btnSave.setText("Save");
        btnSave.addActionListener(this);
        
        lblID.setText("ID: ");
        lblName.setText("Name: ");
        lblSeat.setText("Seat: ");
        lblDate.setText("Date: ");
        lblTime.setText("Time: ");
        lblConcert.setText("Concert: ");
        
        add(btnSave);
        add(lblID);
        add(lblName);
        add(lblSeat);
        add(lblDate);
        add(lblTime);
        add(lblConcert);
        
        add(txtID);
        add(txtName);
        add(txtSeat);
        add(txtConcert);
        add(txtDate);
        add(txtTime);
        
        lblCreate = new JLabel();
        lblCreate.setText("Create New Booking");
        lblCreate.setBounds(500, 0, 150, 50);
        add(lblCreate);
        
        lblNumbers = new JLabel();
        lblNumbers.setText("  10               9               8               7               6               5               4               3               2               1");
        lblNumbers.setBounds(90,130,590,50);
        add(lblNumbers);
        
        lblRowA = new JLabel();
        lblRowA.setText("A");
        lblRowA.setBounds(640,170,50,50);
        add(lblRowA);
                
        lblRowB = new JLabel();
        lblRowB.setText("B");
        lblRowB.setBounds(640,200,50,50);
        add(lblRowB);
        
        lblRowC = new JLabel();
        lblRowC.setText("C");
        lblRowC.setBounds(640,230,50,50);
        add(lblRowC);
        
        lblRowD = new JLabel();
        lblRowD.setText("D");
        lblRowD.setBounds(640,290,50,50);
        add(lblRowD);
        
        lblRowE = new JLabel();
        lblRowE.setText("E");
        lblRowE.setBounds(640,320,50,50);
        add(lblRowE);
        
        lblRowF = new JLabel();
        lblRowF.setText("F");
        lblRowF.setBounds(640,350,50,50);
        add(lblRowF);
        
        lblRowG = new JLabel();
        lblRowG.setText("G");
        lblRowG.setBounds(640,410,50,50);
        add(lblRowG);
        
        lblRowH = new JLabel();
        lblRowH.setText("H");
        lblRowH.setBounds(640,440,50,50);
        add(lblRowH);
                
        lblRowI = new JLabel();
        lblRowI.setText("I");
        lblRowI.setBounds(640,470,50,50);
        add(lblRowI);
        
               
        GoldSeats = new JPanel();
        GoldSeats.setBounds(90,185,500,80);
        SilverSeats = new JPanel();
        SilverSeats.setBounds(90,305,500,80);
        BronzeSeats = new JPanel();
        BronzeSeats.setBounds(90,425,500,80);
        
        buttons = new JButton[btn_count/30][btn_count/3]; //initialising the array
            
        for(int i = 0; i < 3; i++){ //setting a for loop for the 3 colours
            for(int j=0; j< 30; j++){ // for loop for 30 buttons
                buttons[i][j] = new JButton();

                        if(i == 0){
                
                            buttons[i][j].setBackground(new java.awt.Color(204, 153, 0));
                            buttons[i][j].setForeground(new java.awt.Color(204, 153, 0));
                            
                            gold = buttons[0][j];
                            
                            experimentLayout =  new GridLayout(3,10);
                            experimentLayout.setVgap(10);
                            experimentLayout.setHgap(10);
                            GoldSeats.setLayout(experimentLayout);
                            GoldSeats.add(buttons[i][j]);
                            add(GoldSeats); 
                             
                            seat = "gold" + j;
                        }
                        
                        else if (i == 1){

                        
                            buttons[i][j].setBackground(new java.awt.Color(153, 153, 153));
                            buttons[i][j].setForeground(new java.awt.Color(153, 153, 153));
                            SilverSeats.setLayout(experimentLayout);
                            SilverSeats.add(buttons[i][j]);
                            add(SilverSeats);  
                            silver = buttons[i][j];
                            seat = "silver" + j;
                        }
                        else
                        
                            if(i == 2){
                
                            buttons[i][j].setBackground(new java.awt.Color(153, 51, 0));
                            buttons[i][j].setForeground(new java.awt.Color(153, 51, 0));
                            BronzeSeats.setLayout(experimentLayout);
                            BronzeSeats.add(buttons[i][j]);
                            add(BronzeSeats);  
                            
                            bronze = buttons[i][j];
                            seat = "bronze" + i + j;
                        }
                
                        buttons[i][j].setOpaque(true);
                
                       
                        gold.addActionListener(new ActionListener() {
                    
                            public void actionPerformed(ActionEvent evt) {
                                
                                 goldActionPerformed(evt);
                                 
                            }
               
                        });
                        
                        //silver.addActionListener(new ActionListener() {
                    
                        //    public void actionPerformed(ActionEvent evt) {
                                
                        //         silverActionPerformed(evt);
                                 
                        //    }
               
                        //});
                        
                        //bronze.addActionListener(new ActionListener() {
                    
                        //    public void actionPerformed(ActionEvent evt) {
                                
                        //         bronzeActionPerformed(evt);
                                 
                        //    }
               
                        //});
            
            }
    
        }   

    }

    
 private void goldActionPerformed(java.awt.event.ActionEvent evt) 
 {
     txtSeat.setText(seat);
 }    
  private void silverActionPerformed(java.awt.event.ActionEvent evt) 
  {
      txtSeat.setText(seat);
  }
  private void bronzeActionPerformed(java.awt.event.ActionEvent evt)
  {
      txtSeat.setText(seat);
  } 

    @Override
    public void actionPerformed(ActionEvent e) 
    {
        //this.setVisible(false);
        if(e.getSource() == btnSave)
        {
            id = "";
            name = "";
            date = "";
            concert = "";
            time = "";
            
            id = txtID.getText().trim();
            name = txtName.getText().trim();
            seat = txtSeat.getText().trim();
            date= txtDate.getText().trim();
            concert=txtConcert.getText().trim();
            time = txtTime.getText().trim();
            summary = ("ID:"+(id)+ " Name:"+(name)+ " Seat:" +(seat)+" Concert:"+(concert)+ " Date:"+(date)+" Time:"+(time));
            String Data = Events.summary;
            
            try
            {    
                BufferedWriter reader = new BufferedWriter(new FileWriter(new File ("C:\\Users\\Owner\\Desktop\\GUINewConcert0_0_3\\GUINewConcert\\src\\addbooking\\customerdetails.txt"), true));
                reader.write(Data);
                reader.newLine();
                reader.close();            
            }
            catch(IOException E)
            {
                System.out.print("Error is" + E);
            }
        }
    }
}